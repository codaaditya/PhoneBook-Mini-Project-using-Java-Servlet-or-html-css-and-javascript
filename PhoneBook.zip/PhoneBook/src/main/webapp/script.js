document.addEventListener('DOMContentLoaded', function() {
    fetch('CheckLogin')
        .then(response => response.json())
        .then(data => {
            if (data.loggedIn) {
                document.getElementById('user-info').innerText = `Welcome, ${data.username}!`;
                document.getElementById('logout-button').style.display = 'block';
            } else {
                document.getElementById('user-info').innerText = '';
                document.getElementById('logout-button').style.display = 'none';
            }
        })
        .catch(error => console.error('Error:', error));
});
/**
 * 
 */