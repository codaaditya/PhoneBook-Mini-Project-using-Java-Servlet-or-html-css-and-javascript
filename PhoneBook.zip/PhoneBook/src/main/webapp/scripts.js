document.addEventListener("DOMContentLoaded", function() {
    // Fetch user session state from the server
    fetch('/checkSession')
        .then(response => response.json())
        .then(data => {
            const welcomeMessage = document.getElementById('welcome-message');
            const logoutBtn = document.getElementById('logout-btn');
            const loginBtn = document.getElementById('login-btn');
            const registerBtn = document.getElementById('register-btn');

            if (data.loggedIn) {
                welcomeMessage.textContent = `Welcome, ${data.username}!`;
                logoutBtn.style.display = 'inline';
                loginBtn.style.display = 'none';
                registerBtn.style.display = 'none';
            } else {
                welcomeMessage.textContent = '';
                logoutBtn.style.display = 'none';
                loginBtn.style.display = 'inline';
                registerBtn.style.display = 'inline';
            }
        });
});

    // Function to load the username dynamically
    function loadUsername() {
        // Send an AJAX request to get the username from the session
        fetch('GetUsername')
            .then(response => response.text())
            .then(username => {
                // If username exists, display it; otherwise, show "Guest"
                if (username) {
                    document.getElementById('usernameDisplay').innerText = `Hello, ${username}!`;
                } else {
                    document.getElementById('usernameDisplay').innerText = `Hello, Guest!`;
                }
            });
    }

    window.onload = loadUsername;
