import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/GetUsername")
public class GetUsername extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the current session
        HttpSession session = request.getSession(false);

        // If session exists, retrieve the username
        if (session != null) {
            String username = (String) session.getAttribute("username");
            if (username != null) {
                response.getWriter().write(username);
                return;
            }
        }

        // If session or username is not available, send an empty response
        response.getWriter().write("");
    }
}
