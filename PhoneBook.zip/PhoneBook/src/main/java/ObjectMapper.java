
public class ObjectMapper {

	public String writeValueAsString(CheckSession.SessionStatus sessionStatus) {
		// TODO Auto-generated method stub
		return null;
	}

}
